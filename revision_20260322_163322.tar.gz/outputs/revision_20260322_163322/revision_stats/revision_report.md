# Revision Experiment Report

- Output base: `outputs/revision_20260322_163322`
- Ablation presets: baseline, soft_only, no_gate, full

## Ablation Overview

| Mode | Description | J&F | Delta vs Baseline | FPS | Reinits |
| --- | --- | ---: | ---: | ---: | ---: |
| A0 Baseline | SAM2 propagation without drift correction | 0.3609 | +0.0000 | 9.77 | 0 |
| A1 Soft-only | Drift detection with memory refresh only | 0.3600 | -0.0009 | 10.59 | 114 |
| A2 No-gate | Two-tier correction with hard reinit gate disabled | 0.4668 | +0.1059 | 9.93 | 51 |
| A3 Full | Full CoralSAM-Track | 0.4675 | +0.1066 | 9.91 | 48 |

## Method Overview

| Method | J&F | Tail-Head | FPS |
| --- | ---: | ---: | ---: |
| SAM2 baseline | 0.3609 | -0.2652 | 9.77 |
| CoralSAM-Track | 0.4675 | -0.1902 | 9.91 |

